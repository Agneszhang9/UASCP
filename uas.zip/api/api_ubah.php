<?php
require_once '../config/koneksi.php';

if (isset($_POST['id'])) {
    $id                          = $_POST['id'];
    $nama                        = $_POST['nama'];
    $merek                       = $_POST['merek'];
    $produk                      = $_POST['produk'];
    $hp                          = $_POST['hp'];
    $email                       = $_POST['email'];
    $alamat                      = $_POST['alamat'];

    $sql = $conn->prepare("UPDATE skincare SET nama=?, merek=?, produk=?, hp=?, email=?, alamat=? WHERE id=?");
    $sql->bind_param('sssd', $nama, $merek, $produk, $hp, $email, $alamat);
    $sql->execute();
    if ($sql) {
}
        echo json_encode(array('RESPONSE' => 'SUCCESS'));
        header("location:http://localhost/exclusivecare/skincare.php");
        echo json_encode(array('RESPONSE' => 'FAILED'));
    } else {
    }
    echo "GAGAL";