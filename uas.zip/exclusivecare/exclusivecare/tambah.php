<?php
    function http_request($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}

    $data = http_request("http://localhost/exclusivecare/api/api_tampil.php");
    $data = json_decode($data, TRUE); 
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="dist/favicon.ico">

    <title>E X C L U S I V E C A R E</title>

    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="./css/style.css" rel="stylesheet">
  </head>
  <body>

     <!--Navbar-->
     <div class="container-fluid">
     <div class="wrap">
            <div class="header">
                <h1>E X C L U S I V E C A R E</h1> 
        
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item active">
                <a class="nav-link" href="../exclusivecare/index.html">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="../exclusivecare/pre-order.php">Data Pre-Order <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="exclusivecare/contact.html">Contact Us</a>
              </li>
            </ul>
          </div>
       </nav>
    <!--Akhir Navbar-->
    <div class="alert alert-secondary" role="alert">
    <div class="container pt-4">
      <h4>
        <a href="http://localhost/exclusivecare/pre-order.php" class="badge badge-secondary px-2 py-2">Back</a>
      </h4>
    </div>
    <div class="container w-100 bg-info text-light rounded">
	    <form class="form-container p-5" action="http://localhost/exclusivecare/api/api_tambah.php" method="POST" id="form">
		    <div>
		        <h3 class="text-light text-center"><b>Tambah Data Pre-Order</b></h3>
		    </div>
		    <hr class="bg-light">
		    <div class="form-group">
			    <label for="">Name</label>
			    <input type="text" class="form-control" nama="nama" id="nama" aria-describedby="helpId" placeholder="Nama">
		    </div>
        <div class="form-group">
			    <label for="">Brand</label>
			    <input type="text" class="form-control" nama="Merek" id="Merek" aria-describedby="helpId" placeholder="Merek">
		    </div>
        <div class="form-group">
			    <label for="">Product</label>
			    <input type="text" class="form-control" nama="produk" id="produk" aria-describedby="helpId" placeholder="Produk">
		    </div>
            <div class="form-group">
			    <label for="">HP Num.</label>
			    <input type="text" class="form-control" name="hp" id="hp" aria-describedby="helpId" placeholder="08XX XXXX XXXX">
		    </div>
        <div class="form-group">
			    <label for="">Email</label>
			    <input type="text" class="form-control" nama="email" id="email" aria-describedby="helpId" placeholder="email">
		    </div>
            <div class="form-group">
			    <label for="">Alamat</label>
			    <input type="text" class="form-control" name="alamat" id="alamat" aria-describedby="helpId" placeholder="Alamat">
		    </div>
            <button type="submit" name="submit" class="btn btn-outline-warning btn-lg btn-block">Simpan</button>
	    </form>
	  </div>
      </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


    <div class="clear"></div>
            <div class="footer">
                <p> En & Jun @ copyright 2021</p>
            </div>
        </div>
        </div>
    </div>
    </body>
</html>