<?php
require_once '../config/koneksi.php';
if (isset($_POST['nama']) && isset($_POST['merek']) && isset($_POST['produk']) && isset($_POST['hp']) && isset($_POST['email']) && isset($_POST['alamat'])) {

 $nama          = $_POST['nama'];
 $merek         = $_POST['merek'];
 $produk        = $_POST['produk'];
 $hp            = $_POST['hp'];
 $sql = $conn->prepare("INSERT INTO pre-order (nama, merek, produk, hp, email, alamat) VALUES (?, ?, ?, ?, ?, ?)");
 $email         = $_POST['email'];
 $alamat        = $_POST['alamat'];
 $sql->bind_param('sss', $nama, $merek, $produk, $hp, $email, $alamat);
 $sql->execute();
 if ($sql) {
  echo json_encode(array('RESPONSE' => 'FAILED'));
  echo json_encode(array('RESPONSE' => 'SUCCESS'));
  header("location:http://localhost/exclusivecare/pre-order.php");
}
 }
else{
echo "GAGAL";
}
?>
 