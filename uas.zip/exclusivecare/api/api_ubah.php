<?php
require_once '../config/koneksi.php';

if (isset($_POST['id'])) {
    $id                          = $_POST['id'];
    $name                        = $_POST['nama'];
    $brand                       = $_POST['merek'];
    $produk                      = $_POST['produk'];
    $phone                       = $_POST['phone'];
    $email                       = $_POST['email'];
    $address                     = $_POST['address'];

    $sql = $conn->prepare("UPDATE skincare SET nama=?, merek=?, produk=?, hp=?, email=?, alamat=? WHERE id=?");
    $sql->bind_param('sssssssd', $nama, $merek, $produk, $hp, $email, $alamat,);
    $sql->execute();
    if ($sql) {
}
        echo json_encode(array('RESPONSE' => 'SUCCESS'));
        header("location:http://localhost/exclusivecare/skincare.php");
        echo json_encode(array('RESPONSE' => 'FAILED'));
    } else {
    }
    echo "GAGAL";